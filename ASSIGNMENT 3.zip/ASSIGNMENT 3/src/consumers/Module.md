Prints "Hello World!" with a main function.
[//]: # (above is the module summary)

# Module Overview
Prints "Hello World!" as the output to the command line using a main function.
